<?php
// index.php
// 检查用户是否已登录，如果没有登录则重定向到登录页面
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>校园宠物寻主与收养管理系统</title>
    <link rel="stylesheet" href="css/postmessage.css">
</head>
<body>
    <header>
        <h1>校园宠物寻主与收养管理系统</h1>
    </header>
    
    <nav>
		<a href="index.php">公告</a>
        <a href="findmessage.php">寻主信息</a>
        <a href="shouyangmessage.php">收养信息</a>
        <a href="postmessage.php">发布</a>
        <a href="info.php">个人信息</a>
    </nav>
    
    <main>
        <form action="postmessage.php" method="post" enctype="multipart/form-data">
            <label for="type">发布信息类型:</label>
            <select name="type" id="type">
                <option value="find">寻主信息</option>
                <option value="adopt">收养信息</option>
            </select><br><br>

            <label for="content">发布内容:</label><br>
            <textarea name="content" id="content" rows="5" cols="50"></textarea><br><br>

            <label for="image">上传图片:</label>
            <input type="file" name="image" id="image"><br><br>

            <input type="submit" value="发布">
        </form>
    </main>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $type = $_POST["type"];
    $content = $_POST["content"];
    $username=$_SESSION['username'];
    // 处理图片上传逻辑
    $targetDir = "img/";
    $targetFile = $targetDir . basename($_FILES["image"]["name"]);
    move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile);

    // 连接到数据库
    include("db.php");

    // 根据类型存储到不同的表
    if ($type == "find") {
        $sql = "INSERT INTO message (username,content, image) VALUES ('$username','$content', '$targetFile')";
    } elseif ($type == "adopt") {
        $sql = "INSERT INTO message2 (username,content, image) VALUES ('$username','$content', '$targetFile')";
    }

    // 执行插入操作
    if ($conn->query($sql) === TRUE) {
        $message = "已成功发布。";
        echo "<script>alert('$message'); window.location.href='postmessage.php';</script>";
    } else {
        $errorMessage = "发布失败" . $conn->error;
        echo "<script>alert('$errorMessage');</script>";
    }
    $conn->close();
}
?>



