<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>注册 - 校园宠物寻主与收养管理系统</title>
    <link rel="stylesheet" href="css/signup.css">
</head>
<body>
    <div class="signup-container">
        <h1>注册</h1>
        <form id="signup-form" method="post" action="signup.php">
            <label for="username">用户名</label>
            <input type="text" id="username" name="username" required>
            <label for="password">密码</label>
            <input type="password" id="password" name="password" required>

            <label for="confirm-password">确认密码</label>
            <input type="password" id="confirm-password" name="confirm-password" required>

            <button type="submit">注册</button>
        </form>
        <p>已有账号？<a href="login.php">登录</a></p>
    </div>
</body>
</html>


<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取表单提交的数据
    $username = $_POST["username"];
    $password = $_POST["password"];
    $confirmPassword = $_POST["confirm-password"];

    // 假设在注册时，需要对用户名和密码进行非空验证
    if (empty($username) || empty($password) || empty($confirmPassword)) {
        $error_message = "用户名和密码不能为空";
        echo $error_message;
        exit();
    } elseif ($password !== $confirmPassword) {
        $error_message = "两次输入的密码不一致";
        // 验证成功，跳转到登录后的页面
        echo "<h1> $error_message </h1>";
        exit();
    } else {
        // 连接到数据库
        include("db.php");
        // 准备 SQL 语句
        $sql = "INSERT INTO users (username, password) VALUES ('$username', '$password')";
        $sql2= "INSERT INTO user_info (username)  VALUES ('$username')";
        // 执行插入操作
        if ($conn->query($sql) === TRUE) {
            // 注册成功
            $conn->query($sql2);
            $success_message = "恭喜你！！！注册成功！请回到登录页面登录账号";
            echo "<h1> $success_message </h1>";
        } else {
            // 注册失败
            $error_message = "注册失败：账号已存在";
            echo "<h1> $error_message </h1>";
            exit();
        }
        // 关闭数据库连接
        $conn->close();
    }
}
?>