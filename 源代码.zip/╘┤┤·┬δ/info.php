<?php
// index.php
// 检查用户是否已登录，如果没有登录则重定向到登录页面
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>校园宠物寻主与收养管理系统</title>
    <link rel="stylesheet" href="css/index.css">
</head>
<body>
    <header>
        <h1>校园宠物寻主与收养管理系统</h1>
    </header>
    
    <nav>
		<a href="index.php">公告</a>
        <a href="findmessage.php">寻主信息</a>
        <a href="shouyangmessage.php">收养信息</a>
        <a href="postmessage.php">发布</a>
        <a href="info.php">个人信息</a>
    </nav>
    
    <main>
        <h2>个人信息查看及修改</h2>
        <?php
        // 获取当前登录用户的信息，通常从会话中获取
        $currentUser = $_SESSION['username']; // 假设当前登录用户是张三

        // 连接到数据库
        include("db.php");
        // 查询用户信息
        $query = "SELECT * FROM user_info WHERE username = '$currentUser'";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            $userInfo = $result->fetch_assoc();
            ?>
            <form action="info.php" method="post">
                <label for="name">用户名</label>
                <input type="text" id="name" name="name" value="<?php echo $userInfo["username"]; ?>" readonly><br>
                <label for="nickname">昵称</label>
                <input type="text" id="nickname" name="nickname" value="<?php echo $userInfo["nickname"]; ?>"><br>
                <label for="phone">联系方式</label>
                <input type="text" id="phone" name="phone" value="<?php echo $userInfo["phone"]; ?>"><br>
                <label for="address">地址</label>
                <input type="text" id="address" name="address" value="<?php echo $userInfo["address"]; ?>"><br>
                <label for="stu_id">学号</label>
                <input type="text" id="stu_id" name="stu_id" value="<?php echo $userInfo["stu_id"]; ?>"><br>
                <input type="submit" value="保存">
            </form>
            <?php
        } else {
            echo "用户信息不存在。";
        }
        // 关闭数据库连接
        $conn->close();
        ?>
    </main>
</body>
</html>

<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // 获取提交的表单数据
        $newNickname = $_POST["nickname"];
        $newPhone = $_POST["phone"];
        $newAddress = $_POST["address"];
        $newStuId = $_POST["stu_id"];

        // 更新用户信息到数据库
        include("db.php");
    
        // 更新用户信息的 SQL 查询
        $updateQuery = "UPDATE user_info SET nickname='$newNickname', phone='$newPhone', address='$newAddress', stu_id='$newStuId' WHERE username='$currentUser'";
    
        if ($conn->query($updateQuery) === TRUE) {
            $message = "用户信息已成功更新。";
            echo "<script>alert('$message'); window.location.href='info.php';</script>";
        } else {
            $errorMessage = "更新用户信息时出现问题：" . $conn->error;
            echo "<script>alert('$errorMessage');</script>";
        }
    
        // 关闭数据库连接
        $conn->close();
    }
?>
