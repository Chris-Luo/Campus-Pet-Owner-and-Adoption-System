<?php
session_start();
// 连接到数据库
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $messageId = $_POST["messageId"];
    $commentText = $_POST["commentText"];
    $username = $_SESSION["username"]; // 假设你的用户信息保存在 session 中

    // 插入评论到数据库
    $insertCommentSQL = "INSERT INTO comment (username, m_id, content) VALUES ('$username', $messageId, '$commentText')";
    if ($conn->query($insertCommentSQL) === TRUE) {
        $response = array("status" => "success", "message" => "评论已成功提交。");
    } else {
        $response = array("status" => "error", "message" => "提交评论时出现错误：" . $conn->error);
    }

    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}
?>
