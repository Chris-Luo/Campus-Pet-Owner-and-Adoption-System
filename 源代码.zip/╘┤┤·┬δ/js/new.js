document.addEventListener('DOMContentLoaded', function () {
    const studentSection = document.getElementById('student-section');
    const adminSection = document.getElementById('admin-section');
    const adminPanelLink = document.querySelector('a[href="#admin-panel"]');

    // 切换学生和管理员界面
    adminPanelLink.addEventListener('click', function (event) {
        event.preventDefault();
        studentSection.style.display = 'none';
        adminSection.style.display = 'block';
    });
});
