$(document).ready(function() {
		// 点击评论按钮事件
		$(document).on("click", ".comment-btn", function() {
		    var messageId = $(this).data("m-id");
		    var commentText = $(this).siblings(".comment-input").val();
		    // 发送提交评论请求到后端
		    $.post("submit_comment2.php", { messageId: messageId, commentText: commentText }, function(data) {
		        if (data.status === "success") {
		            // 提交评论成功，刷新页面或其他操作
					alert(data.message);
					window.location.href='shouyangmessage.php';
		        } else {
		            // 提交评论失败，处理错误消息
					alert(data.message);
		        }
		    });
		});
});