<?php  
        // 连接到数据库
        $servername = "localhost"; // 你的数据库服务器地址
        $dbUsername = "www_luowang666_c"; // 你的数据库用户名
        $dbPassword = "M3G3r7xjkt4RHb2c"; // 你的数据库密码
        $dbName = "www_luowang666_c"; // 你的数据库名

        $conn = new mysqli($servername, $dbUsername, $dbPassword, $dbName);

        if ($conn->connect_error) {
            die("连接数据库失败：" . $conn->connect_error);
        }
?>