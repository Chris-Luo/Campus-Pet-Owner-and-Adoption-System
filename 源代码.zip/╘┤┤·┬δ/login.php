<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登录 - 校园宠物寻主与收养管理系统</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <h1>校园宠物寻主与收养管理系统</h1>
    <div class="login-container">
        <h1>登录</h1>
        <form id="login-form" method="post" action="login.php" >
            <label for="username">用户名</label>
            <input type="text" id="username" name="username" required>

            <label for="password">密码</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">登录</button>
        </form>
        <p>还没有账号？<a href="signup.php">注册</a></p>
    </div>
    <!-- <script defer src="js/login.js"></script> -->
</body>
</html>

<?php
session_start();
// 验证用户登录
    //
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST["username"];
        $password = $_POST["password"];
        // 连接到数据库
        include("db.php");
        // 查询用户信息
        $sql = "SELECT username, password FROM users WHERE username = '$username'";
        $result = $conn->query($sql);

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $hashedPassword = $row["password"];
            // 验证密码
            if ($password==$hashedPassword) {
                // 验证成功，跳转到登录后的页面
                $_SESSION[username]=$row["username"];
                $_SESSION[password]=$row["password"];
                $conn->close();
                header("Location: index.php");
                exit();
            } else {
                $str="密码错误";
                echo "<h1> $str </h1>";
            }
        } else {
            $str="用户不存在";
            echo "<h1> $str </h1>";
        }
        
        $conn->close();
    }

?>
