<?php
// index.php
// 检查用户是否已登录，如果没有登录则重定向到登录页面
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>校园宠物寻主与收养管理系统</title>
    <link rel="stylesheet" href="css/index.css">
    <!-- 引入Jquery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <header>
        <h1>校园宠物寻主与收养管理系统</h1>
    </header>
    
    <nav>
		<a href="index.php">公告</a>
        <a href="findmessage.php">寻主信息</a>
        <a href="shouyangmessage.php">收养信息</a>
        <a href="postmessage.php">发布</a>
        <a href="info.php">个人信息</a>
    </nav>
    
    <main>
        <?php
		// 连接到数据库
		include("db.php");
		// 查询寻主信息和评论
		$sql = "SELECT user_info.nickname, message.content, message.image, message.username, message.m_id
				FROM user_info INNER JOIN message ON user_info.username = message.username
				ORDER BY message.m_id DESC";  // 假设 message 表有一个 id 列用于排序
		$result = $conn->query($sql);
		// 构建寻主信息和评论的 HTML
		if ($result->num_rows > 0) {
			while ($row = $result->fetch_assoc()) {
				echo '<div class="message">';
				echo '<p><strong>' . $row["nickname"] . '</strong></p>';
				echo '<p>' . $row["content"] . '</p>';
				//如果有图片的话
				if ($row["image"]!="img/") {
					echo '<img src="' . $row["image"] . '" alt="寻主信息图片">';
				}
				//输出水平线
				echo '<hr>';
				// 查询评论
				$messageId = $row["m_id"];
				$commentsSQL = "SELECT user_info.nickname, comment.content
								FROM user_info INNER JOIN comment ON user_info.username = comment.username
								WHERE comment.m_id = $messageId";
				$commentsResult = $conn->query($commentsSQL);
				if ($commentsResult->num_rows > 0) {
					echo '<div class="comments">';
					while ($commentRow = $commentsResult->fetch_assoc()) {
						echo '<p><strong>' . $commentRow["nickname"] . '</strong>: ' . $commentRow["content"] . '</p>';
					}
					echo '</div>';
				}
				
				// 添加评论输入框和提交按钮
				echo '<input type="text" class="comment-input" placeholder="写下你的评论...">';
				echo '<button class="comment-btn" data-m-id="' . $messageId . '">评论</button>';
				echo '</div>';
				//输出空行
				echo '<br>';
				echo '<br>';
				echo '<br>';
				echo '<br>';
			}
		} else {
			echo '<p>暂无寻主信息。</p>';
		}
		$conn->close();
	    ?>
    </main>
    <script defer src="js/findmessage.js"></script>
</body>
</html>


